import sys
sys.stdin = open("input.txt")
def jong( N ):
    if N == 2: return 3
    elif N == 1: return 1
    return jong(N -1) +  2 * jong(N- 2)
T = int(input())
for tc in range(1,T+1):
    N = int(input())
    print("#{} {}".format(tc, jong(N//10)))