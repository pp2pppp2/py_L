import sys
sys.stdin = open("input.txt")

def dfs(v):
    if v==end:
        result[0] = 1
    for i in range(V+1):
        if rd[v][i]:
            dfs(i)

T = int(input())
for tc in range(1,T+1):
    V,E = list(map(int,input().split()))
    rd = [[0 for _ in range(V + 1)] for _ in range(V + 1)]
    result= [0]
    for i in range(E):
        tmp1,tmp2 = list(map(int,input().split()))
        rd[tmp1][tmp2] += 1
    start,end = list(map(int,input().split()))
    dfs(start)
    print("#{} {}" .format(tc,result[0]))
